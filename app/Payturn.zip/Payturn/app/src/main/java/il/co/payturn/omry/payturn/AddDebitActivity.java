package il.co.payturn.omry.payturn;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class AddDebitActivity extends Activity implements View.OnClickListener {

    private ImageView ivBackArrow;
    private Button btnAddDebit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_debit);
        btnAddDebit = (Button) findViewById(R.id.btnAddDebit);
        ivBackArrow = (ImageView) findViewById(R.id.ivAddDebitBack);

        ivBackArrow.setOnClickListener(this);
        btnAddDebit.setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.ivAddDebitBack:
                addDebitBack();
                break;
            case R.id.btnAddDebit:
                addDebitComplete();
                break;
        }
    }

    private void addDebitComplete() {
        Intent intent = new Intent(this, DebitsActivity.class);
        startActivity(intent);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    private void addDebitBack() {
        Intent intent = new Intent(this, DebitsActivity.class);
        startActivity(intent);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }
}
