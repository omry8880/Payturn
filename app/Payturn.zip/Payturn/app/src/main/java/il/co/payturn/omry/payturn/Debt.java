package il.co.payturn.omry.payturn;

public class Debt {
    private String ID;
    private String name;
    private double sum;
    private String date;
    private String debtOwner_ID; //The one who has the debt
    private String debtCollector_ID; //The one who collects the debt
    private String image;
    private String status;

    public Debt(String ID, String name, double sum, String date, String debtOwner_ID, String debtCollector_ID, String image, String status) {
        this.ID = ID;
        this.name = name;
        this.sum = sum;
        this.date = date;
        this.debtOwner_ID = debtOwner_ID;
        this.debtCollector_ID = debtCollector_ID;
        this.image = image;
        this.status = status;
    }

    public Debt() {

    }

}
