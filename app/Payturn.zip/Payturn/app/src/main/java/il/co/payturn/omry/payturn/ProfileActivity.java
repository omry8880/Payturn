package il.co.payturn.omry.payturn;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.FloatingActionButton;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;


public class ProfileActivity extends Activity implements View.OnClickListener {

    private TextView tvProfileFullnameText;
    private TextView tvProfileEmailText;
    private TextView tvProfilePasswordText;
    private ImageView ivProfilePasswordEdit;
    private BottomNavigationView bottomNavigationView;
    private FloatingActionButton fabAddProfilePicture;
    private ImageView ivProfilePicture;

    private SharedPreferences prefs;

    private final int REQUEST_CAMERA = 1;
    private final int REQUEST_GALLERY = 0;
    Uri imageURI;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        tvProfileFullnameText = (TextView) findViewById(R.id.tvProfileFullNameText);
        tvProfileEmailText = (TextView) findViewById(R.id.tvProfileEmailText);
        tvProfilePasswordText = (TextView) findViewById(R.id.tvProfilePasswordText);
        ivProfilePasswordEdit = (ImageView) findViewById(R.id.ivProfilePasswordEdit);
        bottomNavigationView = (BottomNavigationView) findViewById(R.id.bottom_navigation_bar);
        fabAddProfilePicture = (FloatingActionButton) findViewById(R.id.fabAddProfilePicture);
        ivProfilePicture = (ImageView) findViewById(R.id.ivProfilePicture);

        ivProfilePasswordEdit.setOnClickListener(this);
        fabAddProfilePicture.setOnClickListener(this);

        prefs = getSharedPreferences(RegisterActivity.SETTING_PREF, MODE_PRIVATE); //Importing register information (name, email, password) to profile page
        tvProfileFullnameText.setText(prefs.getString(RegisterActivity.FULL_NAME, ""));
        tvProfileEmailText.setText(prefs.getString(RegisterActivity.EMAIL, ""));
        tvProfilePasswordText.setText(prefs.getString(RegisterActivity.PASSWORD, ""));

        bottomNavigationView.setSelectedItemId(R.id.nav_profile); //set bottom navigation item state check

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.nav_home:
                        navigationDirectToHomePage();
                        break;

                    case R.id.nav_dashboard:
                        navigationDirectToDashboardPage();
                        break;
                }
                return true;
            }
        });

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.ivProfilePasswordEdit:
                passwordEditPopup();
                break;
            case R.id.fabAddProfilePicture:
                directToCamera();
                break;
        }
    }

    private void navigationDirectToDashboardPage() {
        Intent intent = new Intent(this, DashboardActivity.class);
        startActivity(intent);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    private void navigationDirectToHomePage() {
        Intent intent = new Intent(this, HomeActivity.class);
        startActivity(intent);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    private void directToCamera() {
        AlertDialog.Builder cameraOrGalleryDialog = new AlertDialog.Builder(this);

        cameraOrGalleryDialog.setMessage("Choose where to pick the image from.");
        cameraOrGalleryDialog.setPositiveButton("Camera", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //user chooses camera
                Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE); //Directs to camera
                startActivityForResult(camera, REQUEST_CAMERA);
            }
        });
        cameraOrGalleryDialog.setNegativeButton("Gallery", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //user chooses gallery
                Intent pickPhotoFromGallery = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI);
                startActivityForResult(pickPhotoFromGallery , REQUEST_GALLERY);
            }
        });
        cameraOrGalleryDialog.show();
    }

    private void passwordEditPopup() {
        AlertDialog.Builder passwordEditDialog = new AlertDialog.Builder(this);

        passwordEditDialog.setMessage("Are you sure you want to edit your password? You may only do so once a month.");
        passwordEditDialog.setPositiveButton("Proceed", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //user chooses yes
            }
        });
        passwordEditDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //user chooses no
            }
        });
        passwordEditDialog.show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {
            if (requestCode == REQUEST_CAMERA && data != null) {

                Bundle bundle = data.getExtras();
                Bitmap bmp = (Bitmap) bundle.get("data");
                ivProfilePicture.setImageBitmap(bmp);

            } else if (requestCode == REQUEST_GALLERY && data != null) {

                imageURI = data.getData();
                ivProfilePicture.setImageURI(imageURI);

            }
        }
    }
}












