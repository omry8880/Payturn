package il.co.payturn.omry.payturn;

import android.app.Activity;

public class DashboardActivity extends Activity {
}
