package il.co.payturn.omry.payturn;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.FloatingActionButton;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

public class DebitsActivity extends Activity implements View.OnClickListener {

    private Button btnDebts;
    private Button btnDebits;
    private FloatingActionButton fabAddDebit;
    private BottomNavigationView bottomNavigationView;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_debits);

        btnDebts = (Button) findViewById(R.id.btnDebts);
        btnDebits = (Button) findViewById(R.id.btnDebits);
        fabAddDebit = (FloatingActionButton) findViewById(R.id.fabAddDebit);
        bottomNavigationView = (BottomNavigationView) findViewById(R.id.bottom_navigation_bar);

        fabAddDebit.setOnClickListener(this);
        //btnDebts.setOnClickListener(this);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.nav_home:
                        directToHomePage();
                        break;
                    case R.id.nav_dashboard:
                        navigationDirectToDashboardPage();
                        break;
                    case R.id.nav_profile:
                        navigationDirectToProfilePage();
                        break;
                }
                return true;
            }
        });

    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.fabAddDebit:
                directToAddDebitPage();
                break;
            case R.id.btnDebts:
                directToHomePage();
                break;
        }

    }

    private void directToAddDebitPage() {
        Intent intent = new Intent(this, AddDebitActivity.class);
        startActivity(intent);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    private void directToHomePage() {
        Intent intent = new Intent(this, HomeActivity.class);
        startActivity(intent);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    private void navigationDirectToDashboardPage() {
        Intent intent = new Intent(this, DashboardActivity.class);
        startActivity(intent);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    private void navigationDirectToProfilePage() {
        Intent intent = new Intent(this, ProfileActivity.class);
        startActivity(intent);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }
}
