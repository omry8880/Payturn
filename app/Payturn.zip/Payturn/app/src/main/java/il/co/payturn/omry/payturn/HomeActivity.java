package il.co.payturn.omry.payturn;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class HomeActivity extends AppCompatActivity implements View.OnClickListener {

    private ImageView ivMenu;
    private TextView tvHeader;
    private Button btnDebts;
    private Button btnDebits;
    private BottomNavigationView bottomNavigationView;
    private TextView tvHelloUser;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        ivMenu = (ImageView) findViewById(R.id.ivMenu);
        tvHeader = (TextView) findViewById(R.id.tvHeader);
        btnDebts = (Button) findViewById(R.id.btnDebts);
        btnDebits = (Button) findViewById(R.id.btnDebits);
        bottomNavigationView = (BottomNavigationView) findViewById(R.id.bottom_navigation_bar);
        tvHelloUser = (TextView) findViewById(R.id.tvHelloUser);

        btnDebts.setOnClickListener(this);
        btnDebits.setOnClickListener(this);

        bottomNavigationView.setSelectedItemId(R.id.nav_home); //set menu's item state check

        //Firebase User Instance
        //FirebaseDatabase database = FirebaseDatabase.getInstance();
        //DatabaseReference userRef = database.getReference("Users").child();
        //tvHelloUser.setText(myRef.child("Users").ge);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Fragment selectedFragment = null;
                switch (item.getItemId()) {
                    case R.id.nav_home:
                        selectedFragment = new HomeFragment();
                    case R.id.nav_dashboard:
                        //navigationDirectToDashboardPage();
                        selectedFragment = new DashboardFragment();
                        break;
                    case R.id.nav_profile:
                        //navigationDirectToProfilePage();
                        selectedFragment = new ProfileFragment();
                        break;
                }
                getSupportFragmentManager().beginTransaction().replace(R.id.)
            }
        });



    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnDebts:
                directToDebtsPage();
                break;
            case R.id.btnDebits:
                directToDebitsPage();
                break;
        }
    }


    private void directToDebitsPage() {
        Intent intent = new Intent(this, DebitsActivity.class);
        startActivity(intent);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    private void directToDebtsPage() {
        Intent intent = new Intent(this, HomeActivity.class);
        startActivity(intent);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    private void navigationDirectToDashboardPage() {
        Intent intent = new Intent(this, DashboardActivity.class);
        startActivity(intent);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    private void navigationDirectToProfilePage() {
        Intent intent = new Intent(this, ProfileActivity.class);
        startActivity(intent);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

}
